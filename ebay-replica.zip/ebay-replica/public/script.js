// script.js
document.getElementById('ebayForm').addEventListener('submit', function (event) {
  event.preventDefault();

  const itemName = document.getElementById('itemName').value;
  const price = document.getElementById('price').value;

  // For simplicity, you can log the data to the console
  console.log('Item Name:', itemName);
  console.log('Price:', price);

  // You can send this data to the server using AJAX or fetch API
});
