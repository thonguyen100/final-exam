const express = require('express');
const path = require('path');
const fs = require('fs').promises;
const app = express();
const port = 3000;

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Specific route handler for the root path
app.get('/', async (req, res, next) => {
  const filePath = path.join(__dirname, 'home.html');
  console.log('Attempting to send file:', filePath);

  try {
    const jsonData = await fs.readFile(path.join(__dirname, 'data.json'), 'utf8');
    console.log('JSON data:', jsonData);

    res.sendFile(filePath, { headers: { 'Content-Type': 'text/html' } }, (err) => {
      if (err) {
        // Check if the error is due to a client disconnecting
        if (err.code === 'ECONNABORTED') {
          console.log('Request aborted by client');
        } else {
          console.error('Error sending file:', err);
          // Instead of sending an error response directly, log the error
          // and consider sending a response if necessary
          return next(err);
        }
      } else {
        console.log('File sent successfully');
      }
    });
  } catch (error) {
    console.error('Error reading JSON file:', error);
    // Send an error response if necessary
    res.status(500).send('Internal Server Error');
  }
});

// Error-handling middleware
app.use((err, req, res, next) => {
  console.error(err);
  // Send an error response if necessary
  res.status(500).send('Internal Server Error');
});

app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
